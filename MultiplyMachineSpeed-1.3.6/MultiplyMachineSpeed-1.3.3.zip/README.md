# MultiplyMachineSpeed

一个可以使你机器机器更快的mod，但是耗电也会增加
A mod can make you machine more fast but more power consumption.

如果你加速的是发电机，那么就会加大发电量，但是消耗的资源更快
If you use this to the generator, it will increase the power generation, but the resources will be consumed faster

支持生产机器，矿机，抽水机，发电机，火箭发射，炮台

first line is fast multiple
second lint is power multiple
"i" can show or not show label


### Installation

1. Install BepInEx
3. Then drag Tp.dll into steamapps/common/Dyson Sphere Program/BepInEx/plugins


### 安装

1. 先安装 BepInEx框架
3. 将MultiplyMachineSpeed.dll拖到 steamapps/common/Dyson Sphere Program/BepInEx/plugins文件夹内
