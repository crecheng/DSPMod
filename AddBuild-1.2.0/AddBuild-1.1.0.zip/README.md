# AddBuild

消耗相同的机器，让你已经建好的机器更快

支持生产机器，矿机，抽水机，发电机

支持长按一直叠加

Consume the same machine, make your already built machine faster

Support production machines, mining machines, pumps, generators

Support long press to always overlay

### Installation

1. Install BepInEx
3. Then drag Tp.dll into steamapps/common/Dyson Sphere Program/BepInEx/plugins


### 安装

1. 先安装 BepInEx框架
3. 将AddBuild.dll拖到 steamapps/common/Dyson Sphere Program/BepInEx/plugins文件夹内
