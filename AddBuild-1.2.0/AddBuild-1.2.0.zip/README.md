# AddBuild

消耗相同的机器，让你已经建好的机器更快

支持生产机器，矿机，抽水机，发电机

支持长按一直叠加

如果你想要叠加研究所，你需要将研究所先设置好生产配方
再手持熔炉进行叠加，叠加时会消耗背包里的研究所

Consume the same machine, make your already built machine faster

Support production machines, mining machines, pumps, generators

Support long press to always overlay

if you want addBuild lab, first, You need to set up the production formula of the institute
then ,hold the smelet to addBuild, it will consume the lab in the backpack

### Installation

1. Install BepInEx
3. Then drag Tp.dll into steamapps/common/Dyson Sphere Program/BepInEx/plugins


### 安装

1. 先安装 BepInEx框架
3. 将AddBuild.dll拖到 steamapps/common/Dyson Sphere Program/BepInEx/plugins文件夹内
