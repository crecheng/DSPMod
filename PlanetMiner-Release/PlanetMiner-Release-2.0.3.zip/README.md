# PlanetMiner

# 星球矿机


运输站能够挖取整个星球的矿物

运输需要设置成本地需求

采矿速度取决与你星球上的矿物堆数和科技

支持设置液体

如果倒数第二格是燃料
当电量不满一半时，那么物流站将会自己用燃料给自己供电

The station can mine the minerals of the entire planet

Transportation needs to set up local demand

Mining speed depends on the number of mineral piles and technology on your planet

Support setting liquid

If the penultimate cell is fuel
When the power is less than half, the logistics station will use fuel to power itself


### Installation

1. Install BepInEx
3. Then drag Tp.dll into steamapps/common/Dyson Sphere Program/BepInEx/plugins


### 安装

1. 先安装 BepInEx框架
3. 将PlanetMiner.dll拖到 steamapps/common/Dyson Sphere Program/BepInEx/plugins文件夹内
