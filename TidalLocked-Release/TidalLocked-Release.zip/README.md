# TidalLocked

# 潮汐锁定

Ctrl L 可以使当前星球潮汐锁定

如果是已经被手动潮汐锁定的

CTRL L 会把当前星球恢复

数据会在mod存档中，跟随存档数据

！需要DSPModSave前置！

Ctrl L can make the local planet TidalLocked

If it has been locked by manual tide

CTRL L will restore the planet

The data will be in the mod archive, following the archived data

！Need DSPModSave mod！

### Installation

1. Install BepInEx
3. Then drag Tp.dll into steamapps/common/Dyson Sphere Program/BepInEx/plugins


### 安装

1. 先安装 BepInEx框架
2. 添加DSPModSave前置
3. 将TidalLocked.dll拖到 steamapps/common/Dyson Sphere Program/BepInEx/plugins文件夹内
