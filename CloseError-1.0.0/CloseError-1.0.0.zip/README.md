# CloseError

允许关闭错误提示
error tip can close

### Installation

1. Install BepInEx
3. Then drag Tp.dll into steamapps/common/Dyson Sphere Program/BepInEx/plugins


### 安装

1. 先安装 BepInEx框架
3. 将CloseError.dll拖到 steamapps/common/Dyson Sphere Program/BepInEx/plugins文件夹内
