# Tp

A mod can send you to other star or planet
if have warning in game, don't worrg, you can save game,then read it.
can input a part of name

### Installation

1. Install BepInEx
3. Then drag Tp.dll into steamapps/common/Dyson Sphere Program/BepInEx/plugins


### 安装

1. 先安装 BepInEx框架
3. 将Tp.dll拖到 steamapps/common/Dyson Sphere Program/BepInEx/plugins文件夹内
