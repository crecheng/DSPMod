# StationAutoCollect

# 运输站自动收集

当运输站的格子设置无本地需求时

运输站会自动收集当前星球矿机中符合的矿物

此收集是发生在传送带之后的


When there is no local demand for the grid settings of the transportation station

The transport station will automatically collect the minerals that match the current planet miner

This collection takes place behind the conveyor belt

### 安装

1. 先安装 BepInEx框架
3. 将StationAutoCollect.dll拖到 steamapps/common/Dyson Sphere Program/BepInEx/plugins文件夹内
