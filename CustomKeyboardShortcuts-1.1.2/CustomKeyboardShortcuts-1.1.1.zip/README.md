# CustomKeyboardShortcuts

一个简易的快捷栏mod，点击编辑可以将物品标记在ui中
编辑完成后，可以按数字键或者点击ui可以将物品持有在手中

A simple shortcut bar mod, click "编辑W" to mark the item in the ui
After click "完成√", you can press number keys or click ui to hold the item in your hand


点击编辑，然后手上拿物品填充按钮
编辑完成之后后点击完成
之后按数字键或者点击按钮
都能将手上物品成为按钮物品

Click "编辑W", and then hold the item filling button in your hand
Click "完成√" after editing
Then press the number key or click the button
Can turn items on hand into button items

### Installation

1. Install BepInEx
3. Then drag Tp.dll into steamapps/common/Dyson Sphere Program/BepInEx/plugins


### 安装

1. 先安装 BepInEx框架
3. 将CustomKeyboardShortcuts.dll拖到 steamapps/common/Dyson Sphere Program/BepInEx/plugins文件夹内
