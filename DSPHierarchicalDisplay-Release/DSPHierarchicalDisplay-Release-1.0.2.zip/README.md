# DSPHierarchicalDisplay

# 戴森球分层显示


在你绘制戴森球的时候可以将某层完全隐藏

在你使用是时候会自动暂停游戏

防止出现错误

在你退出戴森球界面时会自动将隐藏的还原

！！！禁止在隐藏的时候启动运行游戏，会出现某些错误！！！




When you draw the Dyson ball, you can hide a layer completely

It will automatically pause the game when you use it

Prevent errors

When you exit the Dyson Ball interface, it will automatically restore the hidden

! ! ! It is forbidden to start and run the game when hidden, some errors will occur! ! !


### Installation

1. Install BepInEx
3. Then drag Tp.dll into steamapps/common/Dyson Sphere Program/BepInEx/plugins


### 安装

1. 先安装 BepInEx框架
3. 将DSPHierarchicalDisplay.dll拖到 steamapps/common/Dyson Sphere Program/BepInEx/plugins文件夹内
