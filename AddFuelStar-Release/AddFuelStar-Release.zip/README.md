# AddFuelStar

# 给太阳加把火

携带氢燃料棒飞到太阳上

给太阳加燃料，使太阳亮度增加

！需要DSPModSave前置！

Flying to the sun with hydrogen fuel rods

Fuel the sun and increase the brightness of the sun

！Need DSPModSave mod！

### Installation

1. Install BepInEx
3. Then drag Tp.dll into steamapps/common/Dyson Sphere Program/BepInEx/plugins


### 安装

1. 先安装 BepInEx框架
3. 将AddFuelStar.dll拖到 steamapps/common/Dyson Sphere Program/BepInEx/plugins文件夹内
