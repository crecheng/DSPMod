# InfiniteBox

将箱子的自动化格子设置成1格，就是只有1格是蓝背景
箱子会自动使用第一格的物品填充剩下的格子

set box only one blue background 
box will copy first item


### Installation

1. Install BepInEx
3. Then drag Tp.dll into steamapps/common/Dyson Sphere Program/BepInEx/plugins


### 安装

1. 先安装 BepInEx框架
3. 将InfiniteBox.dll拖到 steamapps/common/Dyson Sphere Program/BepInEx/plugins文件夹内
