# ChangeSun

# 偷天换日

先输入你需要更换恒星的名字，可以输入名字的一部分

点击查找，点击你要更换恒星名字的按钮

输入框下出现名字表示选择成功

选择更换类型，点击更换

输入框下会变成更换后恒星的名字

可以更换任意恒星，你可以选择更换的格式

数据会在mod存档中，跟随存档数据

！需要DSPModSave前置！

First enter the name of the star you need to change, you can enter part of the name

Click "Find", click the button you want to change the name of the star

A name appears under the input box to indicate a successful selection

Select the replacement type, click "change"

Under the input box will become the name of the changed star

You can change any star, you can choose the format to change

The data will be in the mod archive, following the archived data

！Need DSPModSave mod！

### Installation

1. Install BepInEx
3. Then drag Tp.dll into steamapps/common/Dyson Sphere Program/BepInEx/plugins


### 安装

1. 先安装 BepInEx框架
2. 添加DSPModSave前置
3. 将ChangeSun.dll拖到 steamapps/common/Dyson Sphere Program/BepInEx/plugins文件夹内
