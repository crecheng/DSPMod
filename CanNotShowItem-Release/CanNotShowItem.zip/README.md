# CanNotShowItem

# 允许不显示实体

允许不显示某些实体
可以提高你游戏帧率
不会影响游戏的正常进行

Allow certain entities not to be displayed
Can improve your game frame rate
Will not affect the normal progress of the game

### Installation

1. Install BepInEx
3. Then drag Tp.dll into steamapps/common/Dyson Sphere Program/BepInEx/plugins


### 安装

1. 先安装 BepInEx框架
3. 将CanNotShowItem.dll拖到 steamapps/common/Dyson Sphere Program/BepInEx/plugins文件夹内
