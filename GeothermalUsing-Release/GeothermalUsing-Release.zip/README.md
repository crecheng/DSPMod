# GeothermalUsing

# 熔岩利用

物流站建在熔岩星球上时

当有水，空电池和满电池位置时

会消耗水将空电池充满

当有可燃冰，空电池和石墨烯，满电池位置时

会分解可燃冰产生石墨烯并且给电池充电


When the logistics station was built on the lava planet

When there is water, empty battery and full battery position

Will consume water to fully charge an empty battery

When there is combustible ice, empty battery and graphene, when the battery is full

Will decompose combustible ice to produce graphene and charge the battery



### Installation

1. Install BepInEx
3. Then drag Tp.dll into steamapps/common/Dyson Sphere Program/BepInEx/plugins


### 安装

1. 先安装 BepInEx框架
3. 将GeothermalUsing.dll拖到 steamapps/common/Dyson Sphere Program/BepInEx/plugins文件夹内
