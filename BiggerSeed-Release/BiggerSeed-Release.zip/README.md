# BiggerSeed

# 更多种子

种子上限更大了

上限为2147483647（约21亿）

这不会损坏你的存档

seed max 2147483647(about 2 Billion)

### Installation

1. Install BepInEx
3. Then drag Tp.dll into steamapps/common/Dyson Sphere Program/BepInEx/plugins


### 安装

1. 先安装 BepInEx框架
3. 将BiggerSeed.dll拖到 steamapps/common/Dyson Sphere Program/BepInEx/plugins文件夹内
